# resiliaFrontEnders
Projeto em grupo do segundo modulo da Resilia: JS, HTML, CSS, PITCH
